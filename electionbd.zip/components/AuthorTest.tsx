import Image from "next/image";
import React from "react";


const AuthorTest = ({author}:any) => {
  return (
    <div>AuthorTest</div>
  )
}

export default AuthorTest