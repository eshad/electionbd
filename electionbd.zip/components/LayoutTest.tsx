import Header from './HeaderTest';

const LayoutTest = ({ children }:any) => (
  <>
    <Header />
    {children}
  </>
);

export default LayoutTest;
